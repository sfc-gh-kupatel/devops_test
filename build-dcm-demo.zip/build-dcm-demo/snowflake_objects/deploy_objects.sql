EXECUTE IMMEDIATE FROM './databases/demo_db/schemas/demo_schema/tables/my_inventory.sql';
